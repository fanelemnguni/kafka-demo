## Springboot Kafka Demo

This project is based on the springboot starter base project. 
You need to have kafka installed up and running before running this project

How to run it locally : *mvn spring-boot:run*

How to access locally : *http://localhost:8080/kafka-demo/index.html*
- Swagger : Endpoint documentation and testing